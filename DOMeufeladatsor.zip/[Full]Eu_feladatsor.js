const EuropaiUnio = [{
    orszag: "Ausztria",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Belgium",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Bulgária",
    csatlakozas: "2007.01.01"
},
{
    orszag: "Ciprus",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Csehország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Dánia",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Egyesült Királyság",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Észtország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Finnország",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Franciaország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Görögország",
    csatlakozas: "1981.01.01"
},
{
    orszag: "Hollandia",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Horvátország",
    csatlakozas: "2013.07.01"
},
{
    orszag: "Írország",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Lengyelország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Lettország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Litvánia",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Luxemburg",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Magyarország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Málta",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Németország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Olaszország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Portugália",
    csatlakozas: "1986.01.01"
},
{
    orszag: "Románia",
    csatlakozas: "2007.01.01"
},
{
    orszag: "Spanyolország",
    csatlakozas: "1986.01.01"
},
{
    orszag: "Svédország",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Szlovákia",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Szlovénia",
    csatlakozas: "2004.05.01"
}
];
//F01 - TagokSzama
function TagokSzama(vizsgaltTomb) {
    return vizsgaltTomb.length;
}
document.querySelector("#tagokSzama").innerHTML=TagokSzama(EuropaiUnio)

//F02 - Csatlakozott
function Csatlakozott(vizsgaltTomb) {
    let csatlakozott = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.includes(document.querySelector("#evSzam").value))//split, slice, includes
            csatlakozott++;
    }
    return csatlakozott
}
function megjelenit() {
    let ev= document.querySelector("#evSzam").value.trim();
    let szam = Csatlakozott(EuropaiUnio);
    let eredmeny= document.getElementById("eredmeny");

    if(szam==0){
        eredmeny.innerHTML=`<p>Nem csatlakozott senki ${evSzam.value}-ben!</p>`
    }
    else{
        eredmeny.innerHTML=`Csatlakozott országok száma:<span id="szama">${szam}</span>`
    }
    eredmeny.style.display="block"
}


/*

//F02 - Csatlakozott Univerzális
function CsatlakozottUniverzalis(vizsgaltTomb, csatlakozasEve) {
    let csatlakozottakSzama = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.includes(csatlakozasEve))//split, slice, includes
            csatlakozottakSzama++;
    }
    return csatlakozottakSzama;
}

function CsatlakozottUniverzalisKiir(csatlakozott, evszam) {
    console.log(`A ${evszam}-ben csatlakozott országok száma: ${csatlakozott}`);
}

feladat02EredmenyV2 = CsatlakozottUniverzalis(EuropaiUnio, 2004)
CsatlakozottUniverzalisKiir(feladat02EredmenyV2, 2004);//10 db


//F03 - CsatlakozottEMagyarorszag
function CsatlakozottEMagyarorszag(vizsgaltTomb) {
    let csatlakozottE = false;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].orszag == "Magyarország") {
            csatlakozottE = true;
        }
    }
    return csatlakozottE;
}

function CsatlakozottEMagyarorszagKiir(csatlakozottE) {
    if (csatlakozottE == true) {
        console.log("Magyarország csatlakozott az Európai Unio-hoz");
    }
    else {
        console.log("Magyarország NEM csatlakozott az Európai Unio-hoz");
    }
}
feladat03Eredmeny = CsatlakozottEMagyarorszag(EuropaiUnio)
CsatlakozottEMagyarorszagKiir(feladat03Eredmeny);//igen



//F03 - CsatlakozottEUniverzalis
function CsatlakozottEUniverzalis(vizsgaltTomb, orszagNeve) {
    let csatlakozottE = false;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].orszag == orszagNeve) {
            csatlakozottE = true;
        }
    }
    return csatlakozottE;
}

function CsatlakozottEUniverzalisKiir(csatlakozottE, orszagNeve) {
    if (csatlakozottE == true) {
        console.log(`${orszagNeve} csatlakozott az Európai Unio-hoz`);
    }
    else {
        console.log(`${orszagNeve} NEM csatlakozott az Európai Unio-hoz`);
    }
}
feladat03EredmenyV2 = CsatlakozottEUniverzalis(EuropaiUnio, "Zimbabve")
CsatlakozottEUniverzalisKiir(feladat03EredmenyV2, "Zimbabve");//nem

feladat03EredmenyV3 = CsatlakozottEUniverzalis(EuropaiUnio, "Dubai")
CsatlakozottEUniverzalisKiir(feladat03EredmenyV3, "Dubai");//nem

feladat03EredmenyV4 = CsatlakozottEUniverzalis(EuropaiUnio, "Hollandia")
CsatlakozottEUniverzalisKiir(feladat03EredmenyV4, "Hollandia");//igen

//F04 - MajusiCsatlakozas
function MajusiCsatlakozas(vizsgaltTomb) {
    let csatlakozottE = false;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.includes(".05.")) {
            csatlakozottE = true;
        }
    }
    return csatlakozottE;
}

function MajusiCsatlakozasKiir(csatlakozottE) {
    if (csatlakozottE == true) {
        console.log("Májusban volt csatlakozás");
    }
    else {
        console.log("Májusban nem volt csatlakozás");
    }
}
feladat04Eredmeny = MajusiCsatlakozas(EuropaiUnio)
MajusiCsatlakozasKiir(feladat04Eredmeny);//igen

//F04 - HonapCsatlakozasUniverzalis
function HonapCsatlakozasUniverzalis(vizsgaltTomb, honapAzonosito) {
    let csatlakozottE = false;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.includes(`.${honapAzonosito}.`)) {
            csatlakozottE = true;
        }
    }
    return csatlakozottE;
}
function HonapNeve(honapAzonosito) {
    if (honapAzonosito == "01") {
        return "Januárban";
    }
    else if (honapAzonosito == "02") {
        return "Februárban";
    }
    else if (honapAzonosito == "03") {
        return "Márciusban";
    }
    else if (honapAzonosito == "04") {
        return "Áprilisban";
    }
    else if (honapAzonosito == "05") {
        return "Májusban";
    }
    else if (honapAzonosito == "06") {
        return "Június";
    }
    else if (honapAzonosito == "07") {
        return "Júliusban";
    }
    else if (honapAzonosito == "08") {
        return "Augusztusban";
    }
    else if (honapAzonosito == "09") {
        return "Szeptermberben";
    }
    else if (honapAzonosito == "10") {
        return "Októberben";
    }
    else if (honapAzonosito == "11") {
        return "Novemberben";
    }
    else {
        return "Decemberben";
    }
}
function HonapCsatlakozasUniverzalisKiir(csatlakozottE, honapAzonosito) {
    let honapNeve = HonapNeve(honapAzonosito)
    if (csatlakozottE == true) {
        console.log(`${honapNeve} volt csatlakozás`);
    }
    else {
        console.log(`${honapNeve} nem volt csatlakozás`);
    }
}
feladat04EredmenyV2 = HonapCsatlakozasUniverzalis(EuropaiUnio, "01")
HonapCsatlakozasUniverzalisKiir(feladat04EredmenyV2, "01");//igen

feladat04EredmenyV2 = HonapCsatlakozasUniverzalis(EuropaiUnio, "12")
HonapCsatlakozasUniverzalisKiir(feladat04EredmenyV2, "12");//nem

//F05 - UtolsoCsatlakozo

function UtolsoCsatlakozo(vizsgaltTomb) {
    let utolsoCsatlakozasDatum = vizsgaltTomb[0].csatlakozas.slice(0, 4);
    let orszagNeve = vizsgaltTomb[0].orszag;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.slice(0, 4) > utolsoCsatlakozasDatum) {
            utolsoCsatlakozasDatum = vizsgaltTomb[i].csatlakozas.slice(0, 4);
            orszagNeve = vizsgaltTomb[i].orszag;
        }
    }
    return orszagNeve;
}

function UtolsoCsatlakozoKiir(orszagNeve) {
    console.log("Az utoljára csatlakozó ország:", orszagNeve);
}

feladat05Eredmeny = UtolsoCsatlakozo(EuropaiUnio)
UtolsoCsatlakozoKiir(feladat05Eredmeny);//Horvátország

//F06 -EU_Statisztika

function StatisztikaV1(vizsgaltTomb) {
    //Kigyűjtöm az éveket, ismétlés nélkül:
    let evek = [];
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE = false;
        let aktEv = vizsgaltTomb[i].csatlakozas.slice(0, 4);
        for (let j = 0; j < evek.length; j++) {
            if (aktEv == evek[j]) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            evek.push(aktEv);
        }
    }
    evek.sort(function (a, b) { return a - b });//Extra nem a feladat része a rendezés :)

    let evekSeged = [];//Melyik évben hány ország csatlakozott... 
    //Kezdőértéket adunk a tömb minden elemének, pontosan annyi legyen ahány év van!
    for (let i = 0; i < evek.length; i++) {
        evekSeged.push(0);
    }

    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let aktEv = vizsgaltTomb[i].csatlakozas.slice(0, 4);
        for (let j = 0; j < evek.length; j++) {
            if (aktEv == evek[j]) {
                evekSeged[j]++;
            }
        }
    }
    //Kiírom az eredményt:
    for (let i = 0; i < evek.length; i++) {
        console.log(`${evek[i]}:${evekSeged[i]}`);
    }
}
StatisztikaV1(EuropaiUnio)

function StatisztikaV2(vizsgaltTomb) {
    let statisztika = [];
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE = false;
        let aktEv = vizsgaltTomb[i].csatlakozas.slice(0, 4);
        for (let j = 0; j < statisztika.length; j++) {
            if (aktEv == statisztika[j].ev) {
                szerepelE = true;
                statisztika[j].darabSzam += 1;//Ha már szerepelt növelem az értékét
            }
        }
        if (szerepelE == false) {
            let ev = aktEv;
            let darabSzam = 1;//Ha új elemet találok az érték egy lesz
            let ujElem = { ev, darabSzam }
            statisztika.push(ujElem);
        }
    }
    statisztika.sort((a, b) => a.ev - b.ev);//Extra nem a feladat része a rendezés :)
    return statisztika;
}
console.log(StatisztikaV2(EuropaiUnio));
*/