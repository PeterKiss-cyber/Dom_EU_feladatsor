const EuropaiUnio = [{
    orszag: "Ausztria",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Belgium",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Bulgária",
    csatlakozas: "2007.01.01"
},
{
    orszag: "Ciprus",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Csehország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Dánia",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Egyesült Királyság",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Észtország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Finnország",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Franciaország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Görögország",
    csatlakozas: "1981.01.01"
},
{
    orszag: "Hollandia",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Horvátország",
    csatlakozas: "2013.07.01"
},
{
    orszag: "Írország",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Lengyelország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Lettország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Litvánia",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Luxemburg",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Magyarország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Málta",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Németország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Olaszország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Portugália",
    csatlakozas: "1986.01.01"
},
{
    orszag: "Románia",
    csatlakozas: "2007.01.01"
},
{
    orszag: "Spanyolország",
    csatlakozas: "1986.01.01"
},
{
    orszag: "Svédország",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Szlovákia",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Szlovénia",
    csatlakozas: "2004.05.01"
}
];
//1.feladat 
function TagokSzama(vizsgaltTomb) {
    return vizsgaltTomb.length;
}
document.querySelector("#tagokSzama").innerHTML=TagokSzama(EuropaiUnio)

//2.feladat
function Csatlakozott(vizsgaltTomb) {
    let csatlakozott = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.includes(document.querySelector("#evSzam").value))//split, slice, includes
            csatlakozott++;
    }
    return csatlakozott
}
function megjelenit() {
    let eredmeny= document.getElementById("eredmeny");
    let ev = document.querySelector("#evSzam").value.trim()
    if (ev === "") {
        eredmeny.innerHTML = `Az évszám nem megfelelő!`;
    } 
    else {
        let szam = Csatlakozott(EuropaiUnio, ev);

        if (szam === 0) {
            eredmeny.innerHTML = `<p>Nem csatlakozott senki ${ev}-ben!</p>`;
        } else {
            eredmeny.innerHTML = `Csatlakozott országok száma: <span id="szama">${szam}</span>`;
        }
    }
    eredmeny.style.display="block"
}
//3. feladat
function CsatlakozottEMagyarorszag(vizsgaltTomb) {
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].orszag === "Magyarország") {
            return {
                csatlakozott: true,
                ev: vizsgaltTomb[i].csatlakozas
            };
        }
    }
    return {
        csatlakozott: false,
        ev: null
    };
}

function CsatlakozottEMagyarorszagKiir(eredmeny) {
    let csatlakozottE1 = document.getElementById("csatlakozottE1");
    if (eredmeny.csatlakozott === true && eredmeny.ev !== null) {
        csatlakozottE1.innerHTML = `Magyarország csatlakozott az Európai Unióhoz ${eredmeny.ev}.`;
    } else {
        csatlakozottE1.innerHTML = "Magyarország NEM csatlakozott az Európai Unióhoz.";
    }
}


let eredmeny = CsatlakozottEMagyarorszag(EuropaiUnio);
CsatlakozottEMagyarorszagKiir(eredmeny);
//4.feladat
function HonapCsatlakozasUniverzalis(vizsgaltTomb, honapAzonosito) {
    let csatlakozottE = false;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.includes(`.${honapAzonosito}.`)) {
            csatlakozottE = true;
        }
    }
    return csatlakozottE;
}
function HonapNeve(honapAzonosito) {
    if (honapAzonosito == "01") {
        return "Januárban";
    }
    else if (honapAzonosito == "02") {
        return "Februárban";
    }
    else if (honapAzonosito == "03") {
        return "Márciusban";
    }
    else if (honapAzonosito == "04") {
        return "Áprilisban";
    }
    else if (honapAzonosito == "05") {
        return "Májusban";
    }
    else if (honapAzonosito == "06") {
        return "Június";
    }
    else if (honapAzonosito == "07") {
        return "Júliusban";
    }
    else if (honapAzonosito == "08") {
        return "Augusztusban";
    }
    else if (honapAzonosito == "09") {
        return "Szeptermberben";
    }
    else if (honapAzonosito == "10") {
        return "Októberben";
    }
    else if (honapAzonosito == "11") {
        return "Novemberben";
    }
    else {
        return "Decemberben";
    }
}
function HonapCsatlakozasUniverzalisKiir(csatlakozottE, honapAzonosito) {
    let honapKiir=document.getElementById("honapKiir")
    let honapNeve = HonapNeve(honapAzonosito)
    if (csatlakozottE == true) {
        honapKiir.innerHTML=`${honapNeve} volt csatlakozás!`;
    }
    else {
        honapKiir.innerHTML=`${honapNeve} nem volt csatlakozás!`;
    }
}
feladatEredmeny = HonapCsatlakozasUniverzalis(EuropaiUnio, document.getElementById("honapok").value)
HonapCsatlakozasUniverzalisKiir(feladatEredmeny, document.getElementById("honapok").value)

document.getElementById("honapok").addEventListener("change",function(){
    let honap=this.value
    let eredmeny= HonapCsatlakozasUniverzalis(EuropaiUnio,honap);
    HonapCsatlakozasUniverzalisKiir(eredmeny,honap)
})
//5.feladat
function UtolsoCsatlakozo(vizsgaltTomb) {
    let utolsoCsatlakozasDatum = vizsgaltTomb[0].csatlakozas.slice(0, 4);
    let orszagNeve = vizsgaltTomb[0].orszag;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csatlakozas.slice(0, 4) > utolsoCsatlakozasDatum) {
            utolsoCsatlakozasDatum = vizsgaltTomb[i].csatlakozas.slice(0, 4);
            orszagNeve = vizsgaltTomb[i].orszag;
        }
    }
    return orszagNeve;
}

function UtolsoCsatlakozoKiir(orszagNeve) {
    let utolsoCsatlakozo=document.getElementById("utolsoCsatlakozo")
    utolsoCsatlakozo.innerHTML=("Az utoljára csatlakozó ország:", orszagNeve);
}

feladat05Eredmeny = UtolsoCsatlakozo(EuropaiUnio)
UtolsoCsatlakozoKiir(feladat05Eredmeny);

// 6.feladat

function StatisztikaV1(vizsgaltTomb) {
    let evek = [];
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE = false;
        let aktEv = vizsgaltTomb[i].csatlakozas.slice(0, 4);
        for (let j = 0; j < evek.length; j++) {
            if (aktEv == evek[j]) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            evek.push(aktEv);
        }
    }
    evek.sort(function (a, b) { return a - b });

    let evekSeged = [];
    for (let i = 0; i < evek.length; i++) {
        evekSeged.push(0);
    }

    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let aktEv = vizsgaltTomb[i].csatlakozas.slice(0, 4);
        for (let j = 0; j < evek.length; j++) {
            if (aktEv == evek[j]) {
                evekSeged[j]++;
            }
        }
    }
        for (let i = 0; i < evek.length; i++) {
        let statisztika1= document.getElementById("statisztika1")
        console.log(`${evek[i]}:${evekSeged[i]}`);
        statisztika1.innerHTML +=`${evek[i]}:${evekSeged[i]} <br>`
    }
}
StatisztikaV1(EuropaiUnio)


